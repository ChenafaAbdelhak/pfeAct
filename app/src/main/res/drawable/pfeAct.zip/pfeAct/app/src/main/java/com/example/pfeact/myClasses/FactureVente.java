package com.example.pfeact.myClasses;

public class FactureVente {
    private long id;
    private String dateVente;
    private String heureVente;
    private double montantTotal;
}
