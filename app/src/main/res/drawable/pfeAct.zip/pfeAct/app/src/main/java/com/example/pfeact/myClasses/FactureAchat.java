package com.example.pfeact.myClasses;

public class FactureAchat {
    private long id;
    private String dateAchat;
    private String heureAchat;
    private double montantTotal;

}
