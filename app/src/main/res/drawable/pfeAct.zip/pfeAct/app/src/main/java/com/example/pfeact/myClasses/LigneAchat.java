package com.example.pfeact.myClasses;

public class LigneAchat {
    private long id;
    private int achatQte;
    private double prixAchat;
    private double prixVente;
}
