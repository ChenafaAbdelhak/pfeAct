package com.example.pfeact.myClasses;

public class Famille {
    private int id;
    private String designation;

    public Famille(int id, String designation) {
        this.id = id;
        this.designation = designation;
    }
}
