package com.example.pfeact.myClasses;

public class LigneVente {
    private long id;
    private int achatQte;
    private double prixAchat;
    private double prixVente;
}
